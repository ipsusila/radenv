The online version of this example can be found at
http://techbase.kde.org/Projects/Marble/Runners/Search

Marble uses so-called runners to calculate routes, do reverse geocoding, parse 
files and search for placemarks (cities, addresses, points of interest, ...). 
This tutorial shows how to use the MarbleRunnerManager class to search for an 
arbitrary string (Karlsruhe in the example below, see Userbase for more 
information on search terms).
