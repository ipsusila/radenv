The online version of this example can be found at
http://techbase.kde.org/Projects/Marble/Runners/ReverseGeocoding

Marble uses so-called runners to calculate routes, do reverse geocoding, parse 
files and search for placemarks (cities, addresses, points of interest, ...). 
This tutorial shows how to use the MarbleRunnerManager class to get a
textual description of a given coordinate.
